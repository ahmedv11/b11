package com.example.gcamlite

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity // تغيير الاستيراد إلى AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() { // تغيير الوراثة إلى AppCompatActivity

    private var imageCapture: ImageCapture? = null
    private lateinit var outputDirectory: File
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var viewFinder: PreviewView // إضافة مرجع لـ PreviewView

    // استخدام كود طلب الصلاحية التقليدي بدلاً من registerForActivityResult
    private val REQUEST_CODE_PERMISSIONS = 10
    private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // تعيين الـ layout

        viewFinder = findViewById(R.id.viewFinder) // الحصول على مرجع لـ PreviewView
        val cameraCaptureButton: Button = findViewById(R.id.camera_capture_button) // الحصول على مرجع للزر

        outputDirectory = getOutputDirectory()
        cameraExecutor = Executors.newSingleThreadExecutor()

        // طلب صلاحيات الكاميرا
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        // إعداد المستمع لزر الالتقاط
        cameraCaptureButton.setOnClickListener { takePhoto() }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(
            baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults) // استدعاء super
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this,
                    "لم يتم منح الصلاحيات من قبل المستخدم.",
                    Toast.LENGTH_SHORT).show()
                finish() // إغلاق التطبيق إذا لم يتم منح الصلاحيات
            }
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            // ربط دورة حياة الكاميرا بدورة حياة المالك
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // إعداد الـ Preview
            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(viewFinder.surfaceProvider)
                }

            imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setFlashMode(FlashMode.AUTO) // دعم الفلاش التلقائي
            .setJpegQuality(100) // جودة عالية
                 // استخدام الإعدادات الافتراضية للإصدارات القديمة
                .build()

            // تحديد الكاميرا الخلفية كافتراضي
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                // إلغاء ربط حالات الاستخدام قبل إعادة الربط
                cameraProvider.unbindAll()

                // ربط حالات الاستخدام بالكاميرا
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture)

            } catch(exc: Exception) {
                Log.e(TAG, "فشل ربط حالة الاستخدام", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        // الحصول على مرجع ثابت لحالة استخدام التقاط الصورة
        val imageCapture = imageCapture ?: return

        // إنشاء ملف إخراج مختوم بالوقت لتخزين الصورة
        val photoFile = File(
            outputDirectory,
            SimpleDateFormat(FILENAME_FORMAT, Locale.US
            ).format(System.currentTimeMillis()) + ".jpg")

        // إنشاء كائن خيارات الإخراج الذي يحتوي على الملف
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        // إعداد مستمع التقاط الصورة، والذي يتم تشغيله بعد التقاط الصورة
        imageCapture.takePicture(
            outputOptions, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Log.e(TAG, "فشل التقاط الصورة: ${exc.message}", exc)
                    Toast.makeText(baseContext, "فشل التقاط الصورة: ${exc.message}", Toast.LENGTH_SHORT).show()
                }

                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val msg = "تم حفظ الصورة بنجاح: ${photoFile.absolutePath}"
                    Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
                    Log.d(TAG, msg)
                }
            })
    }


    private fun getOutputDirectory(): File {
        val mediaDir = externalMediaDirs.firstOrNull()?.let {
            // استخدام اسم بسيط للمجلد لتجنب مشاكل R.string قبل البناء الكامل
            File(it, "GCamLiteImages").apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists()) mediaDir else filesDir
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    companion object {
        private const val TAG = "CameraXBasic"
        private const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
    }
}



    // TODO: لتفعيل وضع العزل Portrait Mode يجب التحقق من دعم CameraX Extensions
    // مثل CameraExtensions and checking ExtensionMode.PORTRAIT
